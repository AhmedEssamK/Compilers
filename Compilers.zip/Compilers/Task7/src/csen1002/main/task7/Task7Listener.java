// Generated from /Users/ahmedessamk/IdeaProjects/Task7/grammar/Task7.g4 by ANTLR 4.13.1
package csen1002.main.task7;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link Task7Parser}.
 */
public interface Task7Listener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link Task7Parser#test}.
	 * @param ctx the parse tree
	 */
	void enterTest(Task7Parser.TestContext ctx);
	/**
	 * Exit a parse tree produced by {@link Task7Parser#test}.
	 * @param ctx the parse tree
	 */
	void exitTest(Task7Parser.TestContext ctx);
}